-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jun 2025 pada 14.14
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cuap_coffee`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `coffees`
--

CREATE TABLE `coffees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `coffees`
--

INSERT INTO `coffees` (`id`, `name`, `description`, `price`, `category`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Red Velvet', 'Minuman Red Velvet adalah minuman manis berwarna merah merona yang terinspirasi dari kue red velvet. Rasanya manis, lembut, dengan sentuhan cokelat ringan', 16000.00, 'Non Coffee', 'coffees/rele79aLseiI16Fmo8BnoYWTqU9Y5aW6vLjr9X5O.jpg', '2025-06-24 07:41:00', '2025-06-27 20:43:37'),
(2, 'Butterscotch Coffee', 'Butterscotch Coffee adalah minuman kopi yang memadukan rasa kopi yang pekat dengan manis creamy dan kaya dari butterscotch.', 20000.00, 'Iced Coffee', 'coffees/hXi0sRUdJxzhqYTFmM9CBb6BdObB18Fcq6Ki8K6c.jpg', '2025-06-24 07:41:00', '2025-06-27 21:17:53'),
(3, 'Wheat Latte', 'Wheat Latte adalah minuman latte bebas kafein yang menggunakan ekstrak atau bubuk gandum sebagai pengganti kopi. Rasanya lembut, sedikit manis alami, dan bersahaja (earthy), disajikan hangat dengan susu untuk tekstur creamy.', 18000.00, 'Non Coffee', 'coffees/jqq7PmEQDUta8YfqcHiRRkQA3NLrgPaDeKtiPV3J.jpg', '2025-06-24 07:41:00', '2025-06-27 20:47:22'),
(4, 'Iced Americano', 'Chilled espresso mixed with cold water for a refreshing coffee experience.', 15000.00, 'Cold Coffee', 'coffees/IUQco5guD3Atmue3eU75qMo04sn8ob5MZVs61x0o.jpg', '2025-06-24 07:41:00', '2025-06-29 03:57:43'),
(6, 'gula aren', 'Kopi gula aren adalah varian minuman kopi yang memadukan cita rasa kopi dengan manis alami dari gula aren (sering juga disebut gula merah atau gula kelapa). Minuman ini populer di Indonesia, terutama karena profil rasanya yang unik dan otentik.', 18000.00, 'Iced Coffee', 'coffees/25pQDyO0HYAHopC2l7pAI7RUpBeFffQ6IhPFATDM.jpg', '2025-06-25 05:06:33', '2025-06-27 21:17:04'),
(12, 'Sparkling Cinnamon', 'Sparkling Cinnamon adalah minuman yang menggabungkan rasa hangat dan manis pedas dari kayu manis dengan sensasi dingin dan segar dari air berkarbonasi atau soda. Biasanya dibuat dengan sirup atau ekstrak kayu manis, es batu, dan air soda, kadang ditambahi perasan jeruk.', 22000.00, 'Mocktail Series', 'coffees/PgCxWgdAnSvQqMW3g2CTlE5yErbNQPWMCyVfBlLP.jpg', '2025-06-26 06:07:39', '2025-06-27 20:54:05'),
(13, 'Espresso', 'A concentrated form of coffee served in small, strong shots.', 25000.00, 'Hot Coffee', NULL, '2025-06-29 00:47:47', '2025-06-29 00:47:47'),
(14, 'Cappuccino', 'Espresso-based coffee topped with foamy milk and sometimes sprinkled with cocoa powder.', 35000.00, 'Hot Coffee', NULL, '2025-06-29 00:47:47', '2025-06-29 00:47:47'),
(15, 'Caffe Latte', 'Coffee drink made with espresso and steamed milk.', 35000.00, 'Hot Coffee', NULL, '2025-06-29 00:47:47', '2025-06-29 00:47:47'),
(16, 'Iced Americano', 'Chilled espresso mixed with cold water for a refreshing coffee experience.', 30000.00, 'Cold Coffee', NULL, '2025-06-29 00:47:47', '2025-06-29 00:47:47'),
(17, 'Vietnamese Coffee', 'Traditional Vietnamese coffee made with robusta beans and condensed milk.', 28000.00, 'Specialty Coffee', NULL, '2025-06-29 00:47:47', '2025-06-29 00:47:47'),
(21, 'Americano', 'Espresso diluted with hot water, creating a light layer of crema.', 15000.00, 'Hot Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 03:57:17'),
(22, 'Mocha', 'Espresso combined with steamed milk and chocolate syrup.', 38000.00, 'Hot Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(24, 'Iced Latte', 'Cold version of latte with espresso and cold milk over ice.', 35000.00, 'Cold Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(25, 'Cold Brew', 'Coffee steeped in cold water for 12-24 hours, resulting in a smooth, less acidic taste.', 32000.00, 'Cold Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(26, 'Iced Cappuccino', 'Chilled cappuccino with espresso, cold milk, and milk foam.', 35000.00, 'Cold Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(28, 'Affogato', 'Espresso poured over vanilla ice cream for a delightful dessert coffee.', 40000.00, 'Specialty Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(29, 'Irish Coffee', 'Hot coffee with Irish whiskey and whipped cream.', 45000.00, 'Specialty Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(30, 'Caramel Macchiato', 'Espresso with steamed milk, vanilla syrup, and caramel drizzle.', 42000.00, 'Specialty Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(31, 'Flat White', 'Espresso with microfoam, creating a velvety texture.', 32000.00, 'Hot Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(32, 'Cortado', 'Espresso cut with a small amount of warm milk to reduce acidity.', 30000.00, 'Hot Coffee', NULL, '2025-06-29 00:48:51', '2025-06-29 00:48:51'),
(33, 'Moonlight kiss', 'Moonlight Kiss adalah mocktail menyegarkan yang memadukan rasa manis dan asam dari buah-buahan tropis. Disajikan dingin dengan es batu dan garnish buah segar, minuman ini menghadirkan sensasi lembut dan elegan seperti ciuman di bawah cahaya bulan cocok untuk dinikmati di suasana santai coffee shop.', 21000.00, 'Mocktail Series', 'coffees/5Xsj0DnCBiPgy0TeGH7ijmyX1iMOuJJzKTX4M9Eu.jpg', '2025-06-29 04:03:42', '2025-06-29 04:03:42');

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_05_11_000001_create_coffees_table', 1),
(6, '2024_05_11_000002_create_orders_table', 1),
(7, '2024_05_11_000003_create_order_items_table', 1),
(8, '2025_06_24_143620_add_is_admin_to_users_table', 1),
(9, '2025_06_29_082550_create_website_contents_table', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `notes` text DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `coffee_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `is_admin`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin Cuap', 'admin@cuap.coffee', 1, NULL, '$2y$10$4kCB0UZMklZdtGq0asRNAOoVGk7wIIZlljdBmt.v5w5Ovxq.qrZsa', NULL, '2025-06-24 07:41:00', '2025-06-26 05:09:39'),
(2, 'Owner Cuap', 'owner@cuap.coffee', 1, NULL, '$2y$10$xlhrAbbLgqAXMEgNKI8UvOybjXnvmLIHHT9PngLxrmmLyfTQjgLfG', 'dgnpciZoGNB6PfmB9CtbKfDsLk8ongNUQegBe1MF5Llju4zkTeg6laVq0Blr', '2025-06-25 04:59:02', '2025-06-26 05:09:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `website_contents`
--

CREATE TABLE `website_contents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `section` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'text',
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `website_contents`
--

INSERT INTO `website_contents` (`id`, `section`, `key`, `content`, `type`, `image_path`, `created_at`, `updated_at`) VALUES
(1, 'home', 'hero_title', 'Cuap Coffee', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 02:07:42'),
(2, 'home', 'hero_subtitle', 'Kopi, Cerita, dan Keluarga. Nikmati pengalaman coffee shop terbaik di kota Anda.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(3, 'home', 'featured_title', 'Menu Andalan Kami', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(4, 'home', 'featured_subtitle', 'Pilihan kopi terbaik yang disukai pelanggan kami', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(5, 'home', 'about_title', 'Tentang Cuap Coffee', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(6, 'home', 'about_text', 'Cuap Coffee adalah coffee shop yang mengutamakan kualitas, kenyamanan, dan kebersamaan. Kami hadir di berbagai kota besar Indonesia, menghadirkan suasana hangat dan menu kopi terbaik untuk Anda.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(7, 'home', 'about_text_2', 'Dengan pengalaman lebih dari 5 tahun, kami telah melayani ribuan pelanggan setia yang mempercayai kualitas kopi dan pelayanan kami.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(8, 'home', 'member_title', 'Jadi Member Cuap Coffee', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(9, 'home', 'member_subtitle', 'Nikmati berbagai keuntungan eksklusif sebagai member kami', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(10, 'home', 'contact_title', 'Hubungi Kami', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(11, 'home', 'contact_subtitle', 'Ada pertanyaan atau ingin memberikan feedback? Kami siap mendengarkan Anda!', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(12, 'about', 'hero_title', 'Tentang Cuap Coffee', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:56:32'),
(13, 'about', 'hero_subtitle', 'Kopi, Cerita, dan Keluarga. Kami hadir untuk Anda yang ingin lebih dari sekadar minum kopi.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(14, 'about', 'stats_years', '3', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 02:43:23'),
(15, 'about', 'stats_branches', '1', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 02:11:44'),
(16, 'about', 'stats_customers', '3K+', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 02:21:30'),
(17, 'about', 'story_title', 'Cerita Kami', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(18, 'about', 'story_text', 'Cuap Coffee dimulai dari kecintaan terhadap kopi dan keinginan untuk menciptakan ruang berkumpul yang hangat. Berawal dari kedai kecil di Jakarta, kami telah berkembang menjadi coffee shop yang dicintai ribuan pelanggan.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(19, 'about', 'story_text_2', 'Kami percaya bahwa kopi bukan hanya minuman, tapi juga medium untuk berbagi cerita, membangun hubungan, dan menciptakan momen-momen berharga dalam hidup.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(20, 'about', 'values_title', 'Nilai-Nilai Kami', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(21, 'about', 'mission_title', 'Visi & Misi', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(22, 'about', 'vision_title', 'Visi', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(23, 'about', 'vision_text', 'Menjadi coffee shop terdepan yang menghubungkan orang-orang melalui pengalaman kopi berkualitas dan suasana yang hangat.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(24, 'about', 'mission_title_2', 'Misi', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(25, 'about', 'mission_text', 'Menyajikan kopi berkualitas dengan harga terjangkau untuk semua kalangan', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(26, 'member', 'hero_title', 'Program Member Cuap Coffee', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(27, 'member', 'hero_subtitle', 'Bergabunglah dengan komunitas member kami dan nikmati berbagai keuntungan eksklusif', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(28, 'member', 'benefit_1_title', 'Diskon 10% Minuman', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(29, 'member', 'benefit_1_text', 'Dapatkan potongan harga untuk semua minuman bagi member setia kami.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(30, 'member', 'benefit_2_title', 'Gratis Kopi Hitam Setiap Tgl 11', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(31, 'member', 'benefit_2_text', 'Setiap tanggal 11, dapatkan kopi hitam gratis untuk member setia.', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(32, 'member', 'benefit_3_title', 'Promo Ulang Tahun', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(33, 'member', 'benefit_3_text', 'Traktir 3 gelas minuman gratis di hari ulang tahunmu!', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(34, 'contact', 'hero_title', 'Hubungi Kami', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(35, 'contact', 'hero_subtitle', 'Ada pertanyaan, kritik, atau saran? Kami siap mendengarkan Anda!', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(36, 'contact', 'form_title', 'Kirim Pesan', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(37, 'contact', 'info_title', 'Informasi Kontak', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(38, 'contact', 'address', 'Jl. Kopi No. 11, Jakarta Pusat', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(39, 'contact', 'email', 'info@cuapcoffee.com', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(40, 'contact', 'phone', '+62 21 1234 5678', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(41, 'contact', 'social_instagram', '@kopicuap', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 03:53:04'),
(42, 'contact', 'social_facebook', 'Cuap Coffee', 'text', NULL, '2025-06-29 01:34:38', '2025-06-29 01:34:38'),
(43, 'about', 'about_image', 'website-content/9BNily7Obwy6JQL8eVrtj3XjV17UA1ADFS65r8OP.jpg', 'image', 'website-content/9BNily7Obwy6JQL8eVrtj3XjV17UA1ADFS65r8OP.jpg', '2025-06-29 02:11:44', '2025-06-29 02:19:22');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `coffees`
--
ALTER TABLE `coffees`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indeks untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_coffee_id_foreign` (`coffee_id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indeks untuk tabel `website_contents`
--
ALTER TABLE `website_contents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `website_contents_section_key_unique` (`section`,`key`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `coffees`
--
ALTER TABLE `coffees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `website_contents`
--
ALTER TABLE `website_contents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_coffee_id_foreign` FOREIGN KEY (`coffee_id`) REFERENCES `coffees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
